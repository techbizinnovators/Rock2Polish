<head>
  <script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '814386532690399');
fbq('track', 'PageView');

fbq('track', 'ViewContent');


</script>
<noscript>
<img height="1" width="1" 
src="https://www.facebook.com/tr?id=693528431337053&ev=PageView
&noscript=1"/>
</noscript>
</head>
  <!--====== BANNER PART START ======-->
  <section class="banner-area banner-style-one position-relative">

    <!-- Follow Circle -->
    <div class="circle-out"></div>

    <div class="d-none d-md-block vertical-text wow fadeIn" data-wow-delay=".3s" style="margin-bottom:-62px;padding-bottom:135px;">
      <ul>
        <li> <a href="https://www.facebook.com/keystargems19"> <i class="fab fa-facebook"></i> Facebook </a> </li>
        <li> <a href="https://instagram.com/keystar_gems?igshid=qbatl0bcam73"> <i class="fab fa-instagram"></i> Instagram </a> </li>
        <li> <a href="https://twitter.com/GemsKeystar"> <i class="fab fa-twitter"></i> Twitter </a> </li>
        <li> <a href="https://www.linkedin.com/in/keystar-gems-0a3a261b9/?originalSubdomain=in"> <i class="fab fa-linkedin"></i> LinkedIn </a> </li>
      </ul>
    </div>
    <div class="d-none d-md-block vertical-text right wow fadeIn" data-wow-delay=".3s">
      <span style="margin-top:0px;margin-left:145px;padding-bottom:155px;">Call us on: </span>
      <span><a href="tel:+91 98240 50012"></a>+91 98240 50012</span>
    </div>


    <div class="container container-custom-two" style="margin-top:-62px;">
      <div class="row align-items-center">
        <div class="col-lg-6 col-md-6">
          <div class="banner-content">
            <span class="promo-tag wow fadeInDown" data-wow-delay=".3s">Everyone Can Shine</span>
            <h2 style="font-size:59px;" class="title wow fadeInLeft" data-wow-delay=".5s">Redefined,<br> Lab-Cultivated<br>Diamonds</h2>
            <ul>
              <li>
                <a class="main-btn btn-filled wow fadeInUp" data-wow-delay=".7s" href="<?php echo base_url(); ?>Main/shop" >Explore Now </a>
              </li>
              <li>

              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 wow fadeInRight" data-wow-delay="0.5s">
          <div class="banner-thumb d-none d-md-block">
            <div class="hero-slider-one">
              <div class="single-thumb">
                <img src="<?php echo base_url(); ?>assets/home_slider1.png" alt="images">
              </div>
         
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--====== INSTAGRAM FEED PART START ======-->
  <center>
  <div class="instagram-feed-section col-lg-10 col-md-10">
        <div class="container-fluid ">
            <div class="instagram-slider">
                <div class="image">
                    <a href="<?php echo base_url();?>assets/shapes/round.png" class="insta-popup">
                        <img src="<?php echo base_url();?>assets/shapes/round_n.png" alt="instagram-feed">
                    </a>
                </div>
                <div class="image">
                    <a href="<?php echo base_url();?>assets/shapes/cushion.png" class="insta-popup">
                        <img src="<?php echo base_url();?>assets/shapes/cushion_n.png" alt="instagram-feed">
                    </a>
                </div>
                <div class="image">
                    <a href="<?php echo base_url();?>assets/shapes/emerald.png" class="insta-popup">
                        <img src="<?php echo base_url();?>assets/shapes/emerald_n.png" alt="instagram-feed">
                    </a>
                </div>
                <div class="image">
                    <a href="<?php echo base_url();?>assets/shapes/heart.png" class="insta-popup">
                        <img src="<?php echo base_url();?>assets/shapes/heart_n.png" alt="instagram-feed">
                    </a>
                </div>
                <div class="image">
                    <a href="<?php echo base_url();?>assets/shapes/marquise.png" class="insta-popup">
                        <img src="<?php echo base_url();?>assets/shapes/marquise_n.png" alt="instagram-feed">
                    </a>
                </div>
                <div class="image">
                    <a href="<?php echo base_url();?>assets/shapes/oval.png" class="insta-popup">
                        <img src="<?php echo base_url();?>assets/shapes/oval_n.png" alt="instagram-feed">
                    </a>
                </div>
                <div class="image">
                    <a href="<?php echo base_url();?>assets/shapes/pearl.png" class="insta-popup">
                        <img src="<?php echo base_url();?>assets/shapes/pear_n.png" alt="instagram-feed">
                    </a>
                </div>
                <div class="image">
                    <a href="<?php echo base_url();?>assets/shapes/princess.png" class="insta-popup">
                        <img src="<?php echo base_url();?>assets/shapes/princess_n.png" alt="instagram-feed">
                    </a>
                </div>
                <div class="image">
                    <a href="<?php echo base_url();?>assets/shapes/radiant.png" class="insta-popup">
                        <img src="<?php echo base_url();?>assets/shapes/radiant_n.png" alt="instagram-feed">
                    </a>
                </div>
          
               
            </div>
        </div>
    </div>
    </center>

    <div class="section-title text-center mb-50">
        <div class="section-title-icon">
       <i class="fa fa-gem"></i>
        </div>
       
        <h2><u>Our diamonds are certified by IGI Antwerp and GIA</u></h2>
      </div>
  <!--====== ABOUT PART START ======-->
  
  <!--====== BANNER PART ENDS ======-->
<!--  <section class="about-section style-2 pt-115 pb-115" style="margin-bottom:-290px;">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 wow fadeInLeft parallax_scroll_down" data-wow-delay=".3s">
            <img src="<?php echo base_url();?>assets/home_about1.jpeg" class="img-fluid" alt="img">
            <p class="mt-20" style="font-size:18px;">Keystar is one among the leading name with the widest collection of lab created diamonds available within the market.</p>
          </div>
          <div class="col-lg-6 wow fadeInRight parallax_scroll_up" data-wow-delay=".3s">
            <div class="abour-text mt-100">
              <div class="section-title mb-30">
                <span class="title-tag">about us</span>
                <h2>Generations In Diamonds</h2>
              </div>
              <p class="mb-20" style="font-size:18px;">Pure Grown Diamonds may be a pioneer within the above-ground, laboratory grown diamond industry and therefore the largest selling grown diamond brand within the us.</p>
              <img src="<?php echo base_url();?>assets/home_about2.jpeg" alt="img">
              <p class="mt-20" style="font-size:18px;">Our diamonds are grown in a complicated facility using minimal energy keeping the world safe from mining impact & presenting a Clean and Green Eco Friendly Lab Grown Diamond. </p>
            </div>
          </div>
        </div>
      </div>
    </section>-->
    
  <section class="about-section" style="position:unset;">
        <div class="container" style="max-width: 1509px;">
           
            <div class="about-text-box" style="background:#1c1b19;margin-top:-60px;"> 
                <div class="row align-items-center">
                
                    <div class="col-lg-6">
                     
                    <video width="600" muted, autoplay="", loop="" class="video-wrap video-wrap-two video-about">
                            <source src="<?php echo base_url();?>assets/master_cut.mp4" type="video/mp4" />

                          </video>
                  
                    </div>
                    <div class="col-lg-6" style="margin-top:-110px;">
                        <div class="about-text">
                           <h3>Master-Cut</h3>
                
                            <p style="font-size:17px;text-align:justify;">
                     
                         
We pledge to cut every facet of our diamond with clarity reflecting luxury from every angle. The quality of our diamonds is par excellence which can be passed down to generations as the optimum style statement. Manmade diamonds are on a verge of making history and have begun to bring about a revolution in the jewellery industry in this decade. 
</p>
<a href="<?php echo base_url(); ?>Main/master_cut" class="main-btn btn-filled mt-40"> Know More</a>
                    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="counter-section" style="margin-top:-100px;">
        <div class="container">
            <!-- Section Title -->
    
            <!-- Counter -->
            <div class="row justify-content-center">
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="counter-box counter-box-two" >
                        <div class="icon">
                            <i class="flaticon-user"></i>
                        </div>
                        <h5><span class="counter" style="font-size:30px;">170</span>k+</h5>
                        <span class="title">Satisfied customers</span>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="counter-box counter-box-two">
                        <div class="icon">
                            <i class="flaticon-suitcase"></i>
                        </div>
                        <h5><span class="counter" style="font-size:30px;">3</span>k+</h5>
                        <span class="title">Operative Distributors</span>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="counter-box counter-box-two">
                        <div class="icon">
                            <i class="flaticon-location-pin"></i>
                        </div>
                        <h5><span class="counter" style="font-size:30px;">4</span>+</h5>
                        <span class="title">Presence in countries</span>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                
                
            
                    <div class="counter-box counter-box-two">
                  
                        <div class="icon">
                            <i class="flaticon-clock"></i>
                        </div>
                        <h5><span class="counter" style="font-size:30px;">40</span>+</h5>
                        <span class="title">Years experience</span>
                      
                    </div>
     
                </div>
            </div>
            <!-- Gallery -->
            
        </div>
    </section>
  <!--  <section class="latest-news pt-120 pb-120">
        <div class="section-fw">
            <div class="row">
                <div class="col-md-4 col-6">
                <div class="counter-box counter-box-two">
                  
                  <div class="icon">
                      <i class="flaticon-clock"></i>
                  </div>
                  <h4><span class="counter">40</span>+</h4>
                  <span class="title">Years experience</span>
                
              </div>

                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="latest-post-box mb-30">
                        
                        <div class="post-desc">
                            <ul class="post-meta">
                                <li>
                                    <a href="#"><i class="fal fa-calendar-alt"></i>28th Aug 2020</a>
                                </li>
                                <li>
                                    <a href="#"><i class="fal fa-user"></i>By Admin</a>
                                </li>
                            </ul>
                            <h4><a href="blog-details.html">We provide you with top notch Jewelry Products</a></h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="latest-post-box mb-30">
                   
                        <div class="post-desc">
                            <ul class="post-meta">
                                <li>
                                    <a href="#"><i class="fal fa-calendar-alt"></i>28th Aug 2020</a>
                                </li>
                                <li>
                                    <a href="#"><i class="fal fa-user"></i>By Admin</a>
                                </li>
                            </ul>
                            <h4><a href="blog-details.html">We provide you with top notch Jewelry Products</a></h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="latest-post-box mb-30">
                   
                        <div class="post-desc">
                            <ul class="post-meta">
                                <li>
                                    <a href="#"><i class="fal fa-calendar-alt"></i>28th Aug 2020</a>
                                </li>
                                <li>
                                    <a href="#"><i class="fal fa-user"></i>By Admin</a>
                                </li>
                            </ul>
                            <h4><a href="blog-details.html">We provide you with top notch Jewelry Products</a></h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore.
                            </p>
                        </div>
                    </div>
                </div>
                
            </div>
            
        </div>
    </section>-->
  <div class="section-title text-center mb-50">
        <div class="section-title-icon">
          <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="45" height="45" x="0" y="0" viewBox="0 0 512 512" xml:space="preserve" class="">
            <path
              d="M369.853,250.251l-100-241C267.53,3.65,262.062,0,255.999,0s-11.531,3.65-13.854,9.251l-100,241    c-1.527,3.681-1.527,7.817,0,11.498l100,241c2.323,5.601,7.791,9.251,13.854,9.251s11.531-3.65,13.854-9.251l100-241    C371.381,258.068,371.381,253.932,369.853,250.251z M255.999,457.861L172.239,256l83.76-201.861L339.759,256L255.999,457.861z"
              fill="#ffffff" />
            <path class="diamond-spark spark-1"
              d="M139.606,118.393l-63-63c-5.858-5.857-15.356-5.857-21.213,0c-5.858,5.858-5.858,15.356,0,21.213l63,63    c2.928,2.929,6.767,4.394,10.606,4.394s7.678-1.465,10.607-4.394C145.465,133.748,145.465,124.25,139.606,118.393z" fill="#ffffff" />
            <path class="diamond-spark spark-2"
              d="M456.607,55.393c-5.858-5.857-15.356-5.857-21.213,0l-63,63c-5.858,5.858-5.858,15.356,0,21.213    c2.928,2.929,6.767,4.394,10.606,4.394s7.678-1.465,10.607-4.394l63-63C462.465,70.748,462.465,61.25,456.607,55.393z" fill="#ffffff" />
            <path class="diamond-spark spark-3"
              d="M139.606,372.393c-5.858-5.857-15.356-5.857-21.213,0l-63,63c-5.858,5.858-5.858,15.356,0,21.213    C58.322,459.535,62.16,461,65.999,461s7.678-1.465,10.607-4.394l63-63C145.465,387.748,145.465,378.25,139.606,372.393z" fill="#ffffff" />
            <path class="diamond-spark spark-4"
              d="M456.607,435.393l-63-63c-5.858-5.857-15.356-5.857-21.213,0c-5.858,5.858-5.858,15.356,0,21.213l63,63    c2.928,2.929,6.767,4.394,10.606,4.394s7.678-1.465,10.607-4.394C462.465,450.748,462.465,441.25,456.607,435.393z" fill="#ffffff" />
          </svg>
        </div>
        <span class="title-tag"> New Collection </span>
        <h2>Custom Jewellery</h2>
      </div>
  <!--====== ROOM SLIDER START ======-->
  <section class="room-slider">
    <div class="container-fluid p-0">
      <div class="row rooms-slider-one">
        <div class="col">
          <div class="slider-img" style="background-image: url(assets/jw/home_jw3.jpeg);">
          </div>
        </div>
        <div class="col">
          <div class="slider-img" style="background-image: url(assets/jw/home_jw4.jpeg);">
          </div>
        </div>
        <div class="col">
          <div class="slider-img" style="background-image: url(assets/jw/home_jw5.jpeg);">
          </div>
        </div>
        <div class="col">
          <div class="slider-img" style="background-image: url(assets/jw/home_jw6.jpeg);">
          </div>
        </div>
        <div class="col">
          <div class="slider-img" style="background-image: url(assets/jw/home_jw7.jpeg);">
          </div>
        </div>
        <div class="col">
          <div class="slider-img" style="background-image: url(assets/jw/home_jw8.jpeg);">
          </div>
        </div>
        <div class="col">
          <div class="slider-img" style="background-image: url(assets/jw/home_jw9.jpeg);">
          </div>
        </div>
      </div>
    </div>
    

    <div class="rooms-content-wrap">

      <div class="container">
        <div class="row justify-content-center justify-content-md-start">
          <div class="col-xl-4 col-lg-5 col-sm-8">
            <div class="room-content-box">
              <div class="slider-count"></div>
              <div class="slider-count-big"></div>
              <div class="room-content-slider">
                <div class="single-content">
                  <div class="icon">
                    <i class="flaticon-bracelet"></i>
                  </div>
                  <h3><a href="<?php echo base_url();?>Main/jewellery">Gold Bracelet</a></h3>
                
                </div>
                <div class="single-content">
                  <div class="icon">
                    <i class="flaticon-earrings"></i>
                  </div>
                  <h3><a href="<?php echo base_url();?>Main/jewellery">Diamond Earings</a></h3>
          
                </div>
                <div class="single-content">
                  <div class="icon">
                    <i class="flaticon-necklace"></i>
                  </div>
                  <h3><a href="<?php echo base_url();?>Main/jewellery">Diamond Necklace</a></h3>
            
                </div>
                <div class="single-content">
                  <div class="icon">
                    <i class="flaticon-necklace"></i>
                  </div>
                  <h3><a href="<?php echo base_url();?>Main/jewellery">Diamond Necklace</a></h3>
             
                </div>
                <div class="single-content">
                  <div class="icon">
                    <i class="flaticon-ring"></i>
                  </div>
                  <h3><a href="<?php echo base_url();?>Main/jewellery">Diamond Rings</a></h3>
            
                </div>
                <div class="single-content">
                  <div class="icon">
                    <i class="flaticon-necklace"></i>
                  </div>
                  <h3><a href="<?php echo base_url();?>Main/jewellery">Diamond Necklace</a></h3>
            
                </div>
                <div class="single-content">
                  <div class="icon">
                    <i class="flaticon-necklace"></i>
                  </div>
                  <h3><a href="<?php echo base_url();?>Main/jewellery">Gold Necklace</a></h3>
            
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="pt-115 pb-115 bg-white cta-sec" style="background-image: url('<?php echo base_url();?>assets/conflict.jpeg');">
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
          <div class="block-text">
            <div class="section-title mb-20">
         
              <h2>Conflict free Diamonds</h2>
            </div>
            <p class="pr-50" style="font-size:17px;">
            As our diamonds are labgrown, they are naturally conflict- free diamonds. Today thousands of natural diamond merchants claim to be affiliated with the Kimberly Process which certifies that a diamond is conflict free . Nevertheless, the Kimberly Process defines conflict diamonds as diamonds that finance rebel movements against recognised governments. It largely fails to see that a large number of diamond mining has encouraged violence , child abuse, environmental degradation, poverty and poor working conditions.
            </span> 
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  
    