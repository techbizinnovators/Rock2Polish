 <!--====== FOOTER PART START ======-->
<!-- <footer class="sigma-footer">
    <div class="sigma-footer-top">
      <div class="container-fluid">
        <div class="row no-gutters">
          <div class="col-lg-8">

            <div class="row">
              <div class="col-lg-6">
                <!--====== Back to top ======-
                <div class="sigma-backto-top">
                  <a href="<?php echo base_url(); ?>#" class="back-to-top" id="backToTop">
                    <i class="fal fa-chevron-up"></i>
                    Back to Top
                  </a>
                </div>
              </div>
                    <div class="col-lg-6">
                <div class="h-100 d-flex align-items-center justify-content-end">
       
                 
        
                </div>
              </div>
            </div>

          <div class="col-lg-4">
             </div>
        </div>
      </div>
    </div>
    <div class="sigma-footer-bottom">
      <div class="container-fluid">
        <div class="sigma-footer-bottom-inner">
          <div class="row no-gutters align-items-end">
            <div class="col-lg-6">
              <div class="sigma-footer-contact">
                <ul>
                  <li>
                    <i class="flaticon-phone"></i>
                    <a href="tel:+919824050012"><span>Phone Number</span> +91 982-405-0012</a>
                  </li>
                  <li>
                    <i class="flaticon-message"></i>
                    <a href="mailto:sales@keystargems.com"><span>Email Address</span>sales@keystargems.com</a>
                  </li>
               
        
              
                </ul>
              </div>
            </div>
 
            
            <div class="col-lg-3">
              <div class="sigma-footer-search">
                <form>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <button><i class="fal fa-search"></i></button>
                    </div>
                    <input type="text" name="#" class="form-control" placeholder="Search...">
                  </div>
                </form>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="sigma-footer-contact style-2">
                <ul>
                  <li>
                    <i class="flaticon-location-pin"></i>
                    <a href="#"><span>Office Address</span>3rd Floor, Krishna Complex,
                      Opp. Varachha Police Station, Mini Bazar Varachha,
                      Surat, GJ - 395006<br> BKC
                      Mumbai,<br> MH - 400051</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


    <!-- Copyright 
    <div class="sigma-copyright">
      <div class="container-fluid">
        <div class="sigma-copyright-inner">
          <div class="row">
          
            <div class="col-lg-6 col-md-5 order-2 order-md-1">
              <p class="sigma-copyright-text">Copyright Keystar Gems</a> - 2020    <a href="https://www.facebook.com/keystargems19"><i class="fab fa-facebook-f" style="font-size:20px;color:#fcd462;"></i></a>
               <a href="https://twitter.com/GemsKeystar"><i class="fab fa-twitter"  style="font-size:20px;color:#fcd462;"></i></a>
               <a href="https://www.linkedin.com/in/keystar-gems-0a3a261b9/?originalSubdomain=in"><i class="fab fa-linkedin"  style="font-size:20px;color:#fcd462;"></i></a>
          
               <a href="https://www.instagram.com/keystar_gems/"><i class="fab fa-instagram"  style="font-size:20px;color:#fcd462;"></i></a>
           </p>
      
               
          
          
            </div>
            <div class="col-lg-6 col-md-7 order-1 order-md-2">
              <div class="sigma-copyright-menu">
                <ul>
                  <li>
                    <a href="https://www.termsofusegenerator.net/live.php?token=Mi4OFMypCbIXT3A50AihtVcWNkpiINVe">Terms of use</a>
                  </li>
                  <li>
                    <a href="https://www.privacypolicygenerator.info/live.php?token=5i2Pgglq2lxZr05boe6icyHBVL5AuVMZ">Privacy Environmental Policy</a>
                  </li>
                  
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>-->
  <a href="#" class="back-to-top" id="backToTop">
        <i class="fal fa-angle-double-up"></i>
    </a>
    <!--====== FOOTER PART START ======-->
    <footer >
   
        <div class="copyright-area pt-20 pb-20">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-5 order-2 order-md-1">
                        <p class="copyright-text" style="font-weight:500;">copyright by@kEYSTAR GEMS 2020</p>
                    </div>
                    <div class="col-md-7 order-1 order-md-2">
                        <div class="social-links">
                            <a href="https://www.facebook.com/keystargems19"><i class="fab fa-facebook-f" target="_blank"></i></a>
                            <a href="https://twitter.com/GemsKeystar"><i class="fab fa-twitter" target="_blank"></i></a>
                            <a href="https://www.instagram.com/keystar_gems"><i class="fab fa-instagram" target="_blank"></i></a>
                            <a href="https://www.linkedin.com/in/keystar-gems-0a3a261b9/?originalSubdomain=in" target="_blank"><i class="fab fa-linkedin"></i></a>
                          
                    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
  
  <!--====== FOOTER PART END ======-->
  <!-- Quick View Modal Start -->
  <div class="modal fade quick-view-modal" id="quickViewModal" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-body">
          <div class="close-btn" data-dismiss="modal">
            <a href="<?php echo base_url(); ?>#" class="remove"><i class="fal fa-times"></i></a>
          </div>
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-5">
                <div class="shop-detail-image">
                  <img src="<?php echo base_url(); ?>assets/img/shop/detail-1.png" class="img-fluid" alt="img">
                </div>
              </div>
              <div class="col-lg-7">
                <div class="shop-detail-content">
                  <h3 class="product-title mb-20">Handmade Golden Ring</h3>
                  <span class="rating mb-20">
                    <span class="text-yellow"><i class="far fa-star"></i></span>
                    <span class="text-yellow"><i class="far fa-star"></i></span>
                    <span class="text-yellow"><i class="far fa-star"></i></span>
                    <span class="text-dark-white"><i class="far fa-star"></i></span>
                    <span class="text-dark-white"><i class="far fa-star"></i></span>
                    <span class="pro-review"> <span>1 Reviews</span>
                    </span>
                  </span>
                  <div class="desc mb-20 pb-20 border-bottom">
                    <span class="price">$390 <span>$480</span></span>
                  </div>
                  <div class="mt-20 mb-20">
                    <div class="d-inline-block other-info">
                      <h6>Availability:
                        <span class="text-success ml-2">In Stock</span>
                      </h6>
                    </div>
                    <div class="ml-2 d-inline-block other-info">
                      <h6>SKU:
                        <span class="grey ml-2">006-bhg</span>
                      </h6>
                    </div>
                  </div>
                  <div class="short-descr mb-20">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip</p>
                  </div>
                  <div class="color-sec mb-20">
                    <label>Color</label>
                    <div class="color-box">
                      <label class="m-0">
                        <input type="radio" name="color">
                        <span class="choose-color red"></span>
                      </label>
                      <label class="m-0">
                        <input type="radio" name="color">
                        <span class="choose-color yellow"></span>
                      </label>
                      <label class="m-0">
                        <input type="radio" name="color">
                        <span class="choose-color blue"></span>
                      </label>
                      <label class="m-0">
                        <input type="radio" name="color">
                        <span class="choose-color green"></span>
                      </label>
                    </div>
                  </div>
                  <div class="color-sec mb-20">
                    <label>Material</label>
                    <div class="color-box">
                      <label class="m-0">
                        <input type="radio" name="material">
                        <span class="choose-material">Gold</span>
                      </label>
                      <label class="m-0">
                        <input type="radio" name="material">
                        <span class="choose-material">Diamond</span>
                      </label>
                      <label class="m-0">
                        <input type="radio" name="material">
                        <span class="choose-material">Silver</span>
                      </label>
                      <label class="m-0">
                        <input type="radio" name="material">
                        <span class="choose-material">Stone</span>
                      </label>
                    </div>
                  </div>
                  <div class="quantity-cart d-block d-sm-flex">
                    <div class="quantity-box">
                      <button type="button" class="minus-btn">
                        <i class="fal fa-minus"></i>
                      </button>
                      <input type="text" class="input-qty" name="name" value="1">
                      <button type="button" class="plus-btn">
                        <i class="fal fa-plus"></i>
                      </button>
                    </div>
                    <div class="cart-btn pl-40">
                      <a href="<?php echo base_url(); ?>#" class="main-btn btn-border">Add to Cart</a>
                    </div>
                  </div>
                  <div class="other-info flex mt-20">
                    <h6>Category:</h6>
                    <ul>
                      <li class="list-inline-item mr-2">
                        <a href="<?php echo base_url(); ?>#" class="grey">Bracelets</a>
                      </li>
                      <li class="list-inline-item mr-2">
                        <a href="<?php echo base_url(); ?>#" class="grey">Rings</a>
                      </li>
                      <li class="list-inline-item">
                        <a href="<?php echo base_url(); ?>#" class="grey">Silver Bracelet</a>
                      </li>
                    </ul>
                  </div>
                  <div class="other-info flex mt-20">
                    <h6>Tags:</h6>
                    <ul>
                      <li class="list-inline-item mr-2">
                        <a href="<?php echo base_url(); ?>#" class="grey">rings</a>
                      </li>
                      <li class="list-inline-item mr-2">
                        <a href="<?php echo base_url(); ?>#" class="grey">necklaces</a>
                      </li>
                      <li class="list-inline-item">
                        <a href="<?php echo base_url(); ?>#" class="grey">bracelet</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!--====== Modal Popup End ======-->
  <!--====== jquery js ======-->
  <script src="<?php echo base_url(); ?>assets/js/vendor/modernizr-3.6.0.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/vendor/jquery-1.12.4.min.js"></script>
  <!--====== Bootstrap js ======-->
  <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
  <!--====== Slick js ======-->
  <script src="<?php echo base_url(); ?>assets/js/slick.min.js"></script>
  <!--====== Isotope js ======-->
  <script src="<?php echo base_url(); ?>assets/js/isotope.pkgd.min.js"></script>
  <!--====== Magnific Popup js ======-->
  <script src="<?php echo base_url(); ?>assets/js/jquery.magnific-popup.min.js"></script>
  <!--====== inview js ======-->
  <script src="<?php echo base_url(); ?>assets/js/jquery.inview.min.js"></script>
  <!--====== counterup js ======-->
  <script src="<?php echo base_url(); ?>assets/js/jquery.countTo.js"></script>
  <!--====== Nice Select ======-->
  <script src="<?php echo base_url(); ?>assets/js/jquery.nice-select.min.js"></script>
  <!--====== Bootstrap datepicker ======-->
  <!--<script src="<?php echo base_url(); ?>assets/js/bootstrap-datepicker.js"></script>-->
  <!--====== Ion Rangeslider ======-->
  <!--<script src="<?php echo base_url(); ?>assets/js/ion.rangeSlider.min.js"></script>-->
  <!--====== Jquery Countdown ======-->
  <script src="<?php echo base_url(); ?>assets/js/jquery.countdown.min.js"></script>
  <!--====== Wow JS ======-->
  <script src="<?php echo base_url(); ?>assets/js/wow.min.js"></script>
  <!--====== Mapbox Map ======-->
  <script src="<?php echo base_url(); ?>assets/js/leaflet.js"></script>
  <!--<script src="<?php echo base_url(); ?>assets/js/mapbox-gl.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/map.js"></script>-->
  <!--====== Main js ======-->
  <script src="<?php echo base_url(); ?>assets/js/main.js"></script>
</body>

</html>